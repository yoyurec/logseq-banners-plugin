# Logseq Plugin Template React

## Features

- plug & play boilerplate with properly defined GitHub action defaults
- develop with HMR, empowered by lightning fast Vite ⚡ with [vite-logseq-plugin](https://github.com/pengx17/vite-plugin-logseq)
- windicss for styling
- pnpm
